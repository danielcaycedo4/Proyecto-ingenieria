%% Robot Arm

% Copyright 2007-2012 The MathWorks, Inc.

%% CAD Software Requirements
% This CAD assembly can be opened in SolidWorks(R) 2004 and higher.
%% Assembly
% Link to the <matlab:system(fullfile(matlabroot,'toolbox/physmod/smlink/smlinkdemos/solidworks/robot','robot.SLDASM')) assembly>
%
% This is a view of the robot arm assembly as modelled in SolidWorks(R).
% 
% <<robot_sw.jpg>>
% 


